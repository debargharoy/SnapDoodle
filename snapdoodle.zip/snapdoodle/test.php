<?php
  include 'scripts/cinfig.php';
  if(mysqli_connect($servername, $un, $pd, $dbname)) {
    echo "Connection to DB Failed";
  }
  else {
    echo "Connection Success";
  }
 ?>
