<?php include 'header.php';
  if($_SESSION['loginStatus']==true) { ?> <script type="text/javascript">
    window.location.href='account.php'
  </script> <?php }
?>
  <!-- About section -->
  <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32 w3-greyscale-min" id="about">
    <div >
      <h1 id="about">SNAPDOODLE</h1>
      <h4 id="about">SUPPORT</h3>
    </div>
  </div>

  <?php
  $email=$loginerr=$password=""; $flag=0;
  if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $conn = mysqli_connect($servername, $un, $pd, $dbname);
    if (!$conn) {
      echo "Connection Failed";
   }
   $query = "SELECT * from login where email='".$email."'";
   $result = mysqli_query($conn,$query);
   $data = mysqli_fetch_assoc($result);
   $pwd = hash('sha512',$password);
   if ($email==$data['email']&&$pwd==$data['pswd']) {
     $_SESSION['loginStatus'] = true;
     $_SESSION['useremail'] = $data['email'];
     $query = "SELECT sname from users where email='".$email."'";
     $result=mysqli_query($conn,$query);
     $data = mysqli_fetch_assoc($result);
     $_SESSION['username']=$data['sname']; ?> <script type="text/javascript">
       window.location.href="account.php";
     </script> <?php
   }
   else {
     $loginerr="Invalid Email or Password!"; $flag=1;
   }
  }
   ?>

  <div class="w3-container w3-center">
    <h2>LOGIN</h2>
  </div>
  <div class="w3-quarter">
    &nbsp;
  </div>
  <div class="w3-half">
    <div class="w3-container w3-center"><?php if($flag==1) echo' <span class="error">Incorrect Email or Password</span>' ?>
      <form class="w3-container" action="" method="post">
        <label for="email">Email</label>
        <input type="email" class="w3-input" name="email" value="" placeholder="Your Email" required><br>
        <label for="password">Password</label>
        <input type="password" name="password" class="w3-input" value="" placeholder="********"> <br>
        <input type="submit" class="w3-button w3-black" name="submit" value="Login">
        <button type="button" class="w3-button w3-black" name="button" onclick="window.location.href='fgpwd.php'">Forgot Password</button>
      </form>
    </div>
  </div>


<!-- End page content -->
</div>


<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

</script>


</body>
</html>
