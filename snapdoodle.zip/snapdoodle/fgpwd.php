<?php include 'header.php';
if($_SESSION['loginStatus']==true) { ?> <script type="text/javascript">
  window.location.href='account.php'
</script> <?php }
?>
  <!-- About section -->
  <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32 w3-greyscale-min" id="about">
    <div >
      <h1 id="about">SNAPDOODLE</h1>
      <h4 id="about">SUPPORT</h3>
    </div>
  </div>
  <?php
    if(isset($_POST['submit_fgpwd']))
    {
      $email = $_POST['support_email'];
      $name = $_POST['name'];
      $msg = "PASSRESET";
      $conn = mysqli_connect($servername,$un,$pd,$dbname);
      $query = "INSERT INTO support (sname,email,message) VALUES ('".$name."','".$email."','".$msg."')";
      if(mysqli_query($conn,$query))
      {
        ?> <script type="text/javascript">
          window.location.href="fgpwd_success.php";
        </script>
        <?php
      }
      else {
        ?> <script type="text/javascript">
          window.location.href="fgpwd_fail.php";
        </script> <?php
      }
    }
   ?>
  <div class="w3-container w3-center">
    <h2>Forgot Password?</h2>
  </div>
  <div class="w3-quarter">
    &nbsp;
  </div>
  <div class="w3-half">
    <div class="w3-container w3-center">
      <form class="w3-container" action="" method="post">
        <label for="name">Name</label>
        <input type="text" class="w3-input" name="name" value="" required placeholder="Your Name">
        <label for="email">Email</label>
        <input type="email" class="w3-input" name="support_email" value="" placeholder="Your Email" required><br>
        <input type="submit" class="w3-button w3-black" name="submit_fgpwd" value="Send Mail">
      </form>
    </div>
  </div>


<!-- End page content -->
</div>


<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

</script>


</body>
</html>
