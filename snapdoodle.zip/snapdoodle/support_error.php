<?php include 'header.php'; ?>
  <!-- About section -->
  <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32 w3-greyscale-min" id="about">
    <div >
      <h1 id="about">SNAPDOODLE</h1>
      <h4 id="about">SUPPORT</h3>
    </div>
  </div>

  <div class="w3-container w3-center">
    <h2>Apologies!</h2><br><br> <h4>An error was encountered. <br><a href="support.php">Please try again</a> </h4>
  </div>


<!-- End page content -->
</div>


<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

</script>


</body>
</html>
