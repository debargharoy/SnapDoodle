<?php include 'header.php'; ?>
  <!-- About section -->
  <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32 w3-greyscale-min" id="about">
    <div >
      <h1 id="about">SNAPDOODLE</h1>
      <h4 id="about">SUPPORT</h3>
    </div>
  </div>
  <?php
    if (isset($_POST['submitsupport'])) {
      $name = $_POST['support_name']; $email = $_POST['support_email']; $msg = $_POST['message'];
      $conn = mysqli_connect($servername, $un, $pd, $dbname);
      $query = "INSERT INTO support (sname,email,message) VALUES ('".$name."','".$email."','".$msg."')";
      if(mysqli_query($conn,$query)) {
        ?> <script> window.location.href="support_success.php"; </script> <?php
      }
      else {
        ?> <script> window.location.href="support_error.php"; </script> <?php
      }
    }
   ?>
  <div class="w3-container w3-center">
    <h2>Reach Us At</h2>
  </div>
  <div class="w3-quarter">
    &nbsp;
  </div>
  <div class="w3-half">
    <div class="w3-container w3-center">
      <form class="w3-container" action="" method="post">
        <label for="name">Name</label>
        <input type="text" class="w3-input" name="support_name" value="" placeholder="Your Name" required><br>
        <label for="email">Email</label>
        <input type="email" class="w3-input" name="support_email" value="" placeholder="Your Email" required><br>
        <label for="message">Message</label>
        <textarea name="message" class="w3-input" rows="8" cols="50" placeholder="Your Message"></textarea><br>
        <input type="submit" class="w3-button w3-black" name="submitsupport" value="Send">
        <input type="reset" class="w3-button w3-black" name="reset" value="Reset">
      </form>
    </div>
  </div>


<!-- End page content -->
</div>


<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

</script>


</body>
</html>
