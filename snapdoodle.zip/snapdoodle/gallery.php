<?php include 'header.php'; ?>
  <!-- About section -->
  <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32 w3-greyscale-min" id="about">
    <div >
      <h1 id="about">SNAPDOODLE</h1>
      <h4 id="about">GALLERY</h3>
    </div>
  </div>
  <?php $query=""; $cat="";
    if(isset($_POST['submitcat'])) {
      $cat = $_POST['category'];
      if($cat!="") { $query = "SELECT * from gallery WHERE category='".$cat."' ORDER BY id DESC"; }
      else { $query = "SELECT * from gallery  ORDER BY id DESC"; }
    }  else { $query = "SELECT * from gallery  ORDER BY id DESC"; } ?>
  <div class="w3-container w3-center">
    <h2>Explore the Pictures</h2>
  </div>
  <div class="w3-container w3-center">
    Filter By Category :
    <form class="" action="" method="post">
      <select class="form-control" name="category">
        <option value="" <?php if($cat=="") echo 'selected' ?> >All</option>
        <option value="LANDSCAPE" <?php if($cat=="LANDSCAPE") echo 'selected' ?>>Landscape</option>
        <option value="NAW" <?php if($cat=="NAW") echo 'selected' ?>>Nature And Wildlife</option>
        <option value="PORTRAIT" <?php if($cat=="PORTRAIT") echo 'selected' ?>>Portrait</option>
        <option value="NIGHT" <?php if($cat=="NIGHT") echo 'selected' ?>>Night Photography</option>
        <option value="MACRO" <?php if($cat=="MACRO") echo 'selected' ?>>Macro</option>
      </select>
      <button type="submit" name="submitcat" class="w3-button-cus w3-teal">Apply Filter</button><br><br>
    </form>
  </div>

<?php
  $conn = mysqli_connect($servername, $un, $pd, $dbname);
  $result = mysqli_query($conn,$query);
  if(mysqli_num_rows($result)>0) { $i=0;
    while ($row=mysqli_fetch_assoc($result)) {
      if($i%3==0) { echo '<div class="w3-row cus_row">'; } ?>
        <div class="w3-third">
          <center><img src="<?php echo $row['path']; ?>" id="gal" onclick="onClick(this)" alt="<?php echo $row['title'].' - By '.$row['uploader'];?>"></center><br>
          <div class="w3-center" style="padding-top: 10px; padding-left: 20px;" id="<?php echo $row['usermail']; ?>">
            <?php echo $row['title']; ?> <br> - By <?php echo $row['uploader']; ?>
          </div>
        </div>
        <?php if($i%3==2) { echo '</div>'; } ++$i;
}}
else { ?>
  <h3 class="w3-center w3-container">Sorry! There are no posts yet. <br>Please checkback soon. </h3>
<?php } mysqli_close($conn);
 ?>

 <div id="modal01" class="w3-modal w3-black" style="padding-top:0" onclick="this.style.display='none'">
   <span class="w3-button w3-black w3-xlarge w3-display-topright">×</span>
   <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
     <img id="img01" class="w3-image">
     <p id="caption"></p>
   </div>
 </div>

<!-- End page content -->
</div>

<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

</script>


</body>
</html>
