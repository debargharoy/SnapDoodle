<?php include 'header.php';
if($_SESSION['loginStatus']==true) { ?> <script type="text/javascript">
  window.location.href='account.php'
</script> <?php }
else { $flag=0;
  $email = $_GET['email'];
}
?>
  <!-- About section -->
  <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32 w3-greyscale-min" id="about">
    <div >
      <h1 id="about">SNAPDOODLE</h1>
      <h4 id="about">SUPPORT</h3>
    </div>
  </div>
  <?php if (isset($_POST['submitreset'])) {
    $pswd=$_POST['password']; $con_pass=$_POST['con_password'];
    if($pswd==$con_pass) {
      $pwd = hash('sha512',$pswd);
      $conn = mysqli_connect($servername,$un,$pd,$dbname);
      $query = "UPDATE login set `pswd` = '".$pwd."' where `email`='".$email."'";
      if(mysqli_query($conn,$query)) {
        mysqli_close($conn);
        ?> <script type="text/javascript">
          window.location.href="login.php";
        </script> <?php
      }
    }
    else {
      $flag=1;
    }
  } ?>
  <div class="w3-container w3-center">
    <h2>Reset Password!</h2>
    <?php if($flag==1) { echo '<span class="error">Passwords Do Not Match!</span>'; } ?>
  </div>
  <div class="w3-quarter">
    &nbsp;
  </div>
  <div class="w3-half">
    <div class="w3-container w3-center">
      <form class="w3-container" action="" method="post">
        <input type="text" name="email" value="<?php echo $email; ?>" hidden>
        <label for="password">New Password</label>
        <input type="password" class="w3-input" name="password" value="" placeholder="********" required><br>
        <label for="password">Confirm Password</label>
        <input type="password" name="con_password" class="w3-input" value="" placeholder="********"> <br>
        <input type="submit" class="w3-button w3-black" name="submitreset" value="Reset">
        <button type="button" class="w3-button w3-black" name="button" onclick="window.location.href='index.php'">Cancel</button>
      </form>
    </div>
  </div>


<!-- End page content -->
</div>


<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

</script>


</body>
</html>
