<?php
//if (isset($_POST['submit'])) {
  include 'scripts/config.php';
  $file = $_FILES['file1'];
  $uploader = $_POST['uploader'];
  $title = $_POST['title'];
  $email = $_POST['email'];
  $category = $_POST['category'];
  $filename = $_FILES['file1']['name'];
  $filesize = $_FILES['file1']['size'];
  $filetempname = $_FILES['file1']['tmp_name'];
  $filetype = $_FILES['file1']['type'];
  $fileerror = $_FILES['file1']['error'];
  $fileext = explode('.',$filename);
  $fileactext = strtolower(end($fileext));
  $allow = array('jpg','jpeg','png');

  if (in_array($fileactext,$allow)) {
    if ($fileerror===0) {
      if ($filesize<20000000) {
          $filenewname = uniqid('',true).".".$fileactext;
          $filedest = "uploads/".$filenewname;
          if(move_uploaded_file($filetempname,$filedest))
          {
            $conn = mysqli_connect($servername, $un, $pd, $dbname);
            $sql = "INSERT INTO gallery (`imagename`,`uploader`,`usermail`,`title`,`path`,`category`) VALUES ('".$filenewname."','".$uploader."','".$email."','".$title."','".$filedest."','".$category."')";
            if(mysqli_query($conn,$sql))
              echo "Upload Success";
            else
              echo "Upload Failed";
            mysqli_close($conn);
          }
          else echo "Upload Failed";
        }
        else echo "Max File Size : 20 Mb";
      }
      else {
        echo "Some Error Occured! Please try again!";
      }
    }
  else {
    echo "Unsupported File Format";
  }
/*  }
  else {
    echo "Invalid type";
  }
*/
 ?>
