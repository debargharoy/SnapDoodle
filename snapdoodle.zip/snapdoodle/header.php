﻿<?php
include 'scripts/config.php';
session_start();
?><!DOCTYPE html>
<html>
<title>SnapDoodle</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link href="https://fonts.googleapis.com/css?family=Cinzel" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="res/custom.css">
<style>

</style>
<body class="w3-light-grey w3-content" style="max-width:1600px">

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-bar-block w3-white w3-animate-left w3-text-grey w3-collapse w3-top w3-center" style="z-index:3;width:300px;font-weight:bold" id="mySidebar"><br>
  <h3 class="w3-padding-64 w3-center" style="color: #ffffff;"><b><a href="index.php">HOME</a></b></h3>
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button-nav w3-padding w3-hide-large">&times; CLOSE</a>
  <a href="gallery.php" onclick="w3_close()" class="w3-bar-item w3-button-nav">GALLERY</a>
  <a href="rules.php" onclick="w3_close()" class="w3-bar-item w3-button-nav">RULE BOOK</a>
  <a href="support.php" onclick="w3_close()" class="w3-bar-item w3-button-nav">SUPPORT</a>
  <a href="guide.php" onclick="w3_close()" class="w3-bar-item w3-button-nav">GUIDE</a>
  <?php if($_SESSION['loginStatus']!=true){ ?>
  <a href="login.php" onclick="w3_close()" class="w3-bar-item w3-button-nav">LOGIN</a>
  <a href="register.php" onclick="w3_close()" class="w3-bar-item w3-button-nav">REGISTER</a>
  <?php } else { ?>
  <a href="account.php" onclick="w3_close()" class="w3-bar-item w3-button-nav">MY ACCOUNT</a>
  <a href="logout.php" onclick="w3_close()" class="w3-bar-item w3-button-nav">LOGOUT</a>
  <?php }?>
  <a href="http://www.vadehraart.com/zakkir-hussain/" onclick="w3_close()" target="_blank" class="w3-bar-item w3-button-nav">JURY</a>
</nav>

<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-white w3-xlarge w3-padding-16" style="background-image: url('media/navimg.jpg');">
  <span class="w3-left w3-padding" style="color:#ffffff; text-decoration: none;"><a href="index.php">HOME</a></span>
  <a href="javascript:void(0)" class="w3-right w3-button-nav" onclick="w3_open()" style="color:#ffffff; text-decoration: none;">☰</a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px">

  <!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
