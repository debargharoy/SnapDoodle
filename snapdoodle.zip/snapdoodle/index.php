<?php include 'header.php'; ?>
  <!-- About section -->
  <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32 w3-greyscale-min" id="about">
    <div >
      <h1 id="about">SNAPDOODLE</h1>
      <h4 id="about">ONLINE PHOTOGRAPHY AWARDS</h4>
    </div>
  </div>

  <div class="w3-container w3-center">
    <h2>Latest Posts</h2>
  </div>


  <?php
    $conn = mysqli_connect($servername, $un, $pd, $dbname);
    $query = "SELECT * from gallery ORDER BY id DESC";
    $result = mysqli_query($conn,$query);
    if(mysqli_num_rows($result)>0) { $i=0;
      while (($row=mysqli_fetch_assoc($result))&&$i<9) { $i++;
   ?>
      <div class="w3-third cus_row">
        <center><img src="<?php echo $row['path']; ?>" id="gal" onclick="onClick(this)" alt="<?php echo $row['title'];?>"></center>
      </div>

  <?php
  }}
  else { ?>
    <h3 class="w3-center w3-container">Sorry! There are no posts yet. <br>Please checkback soon. </h3>
  <?php }
   ?>

  <!-- Modal for full size images on click-->
  <div id="modal01" class="w3-modal w3-black" style="padding-top:0" onclick="this.style.display='none'">
    <span class="w3-button w3-black w3-xlarge w3-display-topright">×</span>
    <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
      <img id="img01" class="w3-image">
      <p id="caption"></p>
    </div>
  </div>



<footer class="w3-container w3-padding-32 w3-center">
  <p style="font-size: 20px">Explore More in <a href="gallery.php">Gallery</a></p>
</footer>

<!-- End page content -->
</div>

<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

</script>


</body>
</html>
