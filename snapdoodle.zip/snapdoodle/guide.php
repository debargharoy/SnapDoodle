<?php include 'header.php'; ?>
  <!-- About section -->
  <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32 w3-greyscale-min" id="about">
    <div >
      <h1 id="about">SNAPDOODLE</h1>
      <h4 id="about">GUIDE</h3>
    </div>
  </div>

  <div class="w3-container w3-center">
    <h2>How To Participate</h2>
  </div>

  <ol style="list-style: 1; padding: 40px;">
    <li style="padding: 10px;">Register on this website from the <a href="register.php">REGISTRATION PAGE</a> </li>
    <li style="padding: 10px;"> <a href="login.php">LOGIN</a> to your account </li>
    <li style="padding: 10px;">Depending on the number of pictures uploaded by you (Max 3/person), you'll be presented with the upload form to post your pictures</li>
    <li style="padding: 10px;">Provide the details and click the upload button</li>
  </ol>

  <div class="w3-container w3-center">
    <h2>Forgot Password?</h2>
  </div>
  <ol style="list-style: 1; padding: 40px;">
    <li style="padding: 10px;"> Go to <a href="login.php">LOGIN PAGE</a> and click <a href="fgpwd.php">FORGOT PASSWORD</a> option </li>
    <li style="padding: 10px;">Alternatively <a href="fgpwd.php">Click Here!</a> </li>
    <li style="padding: 10px;">Enter your account email and press the MAIL button</li>
    <li style="padding: 10px;">You will receive a mail to reset password in next 24hrs</li>
    <li style="padding: 10px;">Use the link in mail to reset your password</li>
  </ol>

  <div class="w3-container w3-center">
    <h2>More Queries?</h2>
    <a href="support.php"> <button type="button" name="button" class="w3-button w3-black">Reach Us</button> </a><br>
    <h3><a href="mailto:snapdoodle.texus@gmail.com">snapdoodle.texus@gmail.com</a></h3> <br>
  </div>

<!-- End page content -->
</div>

<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

</script>


</body>
</html>
