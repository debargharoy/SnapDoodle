<?php
session_start();
if (isset($_POST['submit'])) {
  $usnm = $_POST['username'];
  $pwd = $_POST['pwd'];
  if ($usnm=="admin2@snapdoodle.com"&&$pwd=="ehriHJdsh@#adj12") {
    $_SESSION['login'] = true;
    header("Location: users.php");
  }
  else {
    echo "Invalid Login credentials";
  }
}
 ?>

 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>Login</title>
   </head>
   <body>
     <form class="" action="" method="post">
       <input type="text" name="username" value="" placeholder="username">
       <input type="password" name="pwd" value="" placeholder="passoword">
       <input type="submit" name="submit" value="Login">
     </form>
   </body>
 </html>
