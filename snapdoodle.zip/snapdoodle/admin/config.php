<?php
$un = "2583419_db"; $pd="Abc123h4"; $servername = "fdb18.awardspace.net"; $dbname = "2583419_db";
 ?>
