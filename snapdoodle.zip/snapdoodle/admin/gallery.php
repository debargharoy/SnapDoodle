<?php
include 'config.php';
session_start();
if (!$_SESSION['login']) {
  header("Location: index.php");
}
 ?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
  </head>
  <body>
    <style media="screen">
      td,th {
        padding: 20px;
      }
    </style>
    <div class="">
      <ul>
        <a href="users.php">Users</a>
        <a href="gallery.php">Gallery</a>
        <a href="support.php">Support</a>
        <a href="login.php">Login</a>
        <a href="logout.php">Logout</a>
      </ul>
    </div>
    <h1>Gallery</h1>
    <?php
    if (isset($_POST['submit'])) {
      $query ="SELECT * FROM gallery";
      $conn = mysqli_connect($servername, $un, $pd, $dbname);
      if (!$conn) {
        die("Connection to DataBase Failed!");
      }
      $result = mysqli_query($conn,$query);
      echo "<br><br>".mysqli_num_rows($result)." - Rows Affected";
      echo "<br><br>";
     ?>
    <table>
      <thead>
        <th>id</th>
        <th>imagename</th>
        <th>uploader</th>
        <th>title</th>
        <th>category</th>
        <th>path</th>
      </thead>
      <?php while (($row=mysqli_fetch_assoc($result))) { ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['imagename']; ?></td>
        <td><?php echo $row['uploader']; ?></td>
        <td><?php echo $row['title']; ?></td>
        <td><?php echo $row['category']; ?></td>
        <td><?php echo $row['path']; ?></td>
      </tr>
    <?php }
//print_r($row);

    mysqli_close($conn); }
     ?>
    </table>
  </body>
</html>
