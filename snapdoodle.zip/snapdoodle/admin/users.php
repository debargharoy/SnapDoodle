<?php
include 'config.php';
session_start();
if (!$_SESSION['login']) {
  header("Location: index.php");
}
 ?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
  </head>
  <body>
    <style media="screen">
      td,th {
        padding: 20px;
      }
    </style>
    <div class="">
      <ul>
        <a href="users.php">Users</a>
        <a href="gallery.php">Gallery</a>
        <a href="support.php">Support</a>
        <a href="login.php">Login</a>
        <a href="logout.php">Logout</a>
      </ul>
    </div>
    <h1>Users</h1>
    <?php
    if (isset($_POST['submit'])) {
      $query ="SELECT * FROM users";
      $conn = mysqli_connect($servername, $un, $pd, $dbname);
      if (!$conn) {
        die("Connection to DataBase Failed!");
      }
      $result = mysqli_query($conn,$query);
      echo "<br><br>".mysqli_num_rows($result)." - Rows Affected";
      echo "<br><br>";
     ?>
    <table>
      <thead>
        <th>id</th>
        <th>sname</th>
        <th>email</th>
        <th>phone</th>
        <th>college</th>
        <th>campus</th>
        <th>branch</th>
        <th>syear</th>
        <th>rollno</th>
        <th>dob</th>
        <th>city</th>
        <th>state</th>
        <th>country</th>
      </thead>
      <?php while (($row=mysqli_fetch_assoc($result))) { ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['sname']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td><?php echo $row['phone']; ?></td>
        <td><?php echo $row['college']; ?></td>
        <td><?php echo $row['campus']; ?></td>
        <td><?php echo $row['branch']; ?></td>
        <td><?php echo $row['syear']; ?></td>
        <td><?php echo $row['rollno']; ?></td>
        <td><?php echo $row['dob']; ?></td>
        <td><?php echo $row['city']; ?></td>
        <td><?php echo $row['state']; ?></td>
        <td><?php echo $row['country']; ?></td>
      </tr>
    <?php }
//print_r($row);

    mysqli_close($conn);}
     ?>
    </table>
  </body>
</html>
