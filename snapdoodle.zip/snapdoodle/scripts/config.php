<?php
$un = "2583419_db"; $pd="Abc123h4"; $servername = "pdb23.awardspace.net"; $dbname = "2583419_db";
 ?>
