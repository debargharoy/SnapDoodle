<?php include 'header.php';
if($_SESSION['loginStatus']==true) { ?> <script type="text/javascript">
  window.location.href='account.php'
</script> <?php }
?>
  <!-- About section -->
  <div class="w3-container w3-dark-grey w3-center w3-text-light-grey w3-padding-32 w3-greyscale-min" id="about">
    <div >
      <h1 id="about">SNAPDOODLE</h1>
      <h4 id="about">REGISTER</h3>
    </div>
  </div>
  <?php
  $name=$email=$phone=$dob=$password=$confirm_password=$institute=$campus=$branch=$year=$rollno=$city=$state="";
  $country="INDIA"; $flag=0;
  $nameerr=$emailerr=$phoneerr=$doberr=$passworderr=$instituteerr=$campuserr=$brancherr=$yearerr=$rollnoerr=$cityerr=$stateerr=$countryerr="";
  if (isset($_POST['submit'])) {
    function test_input($data) { $data = trim($data); $data = stripslashes($data); $data = htmlspecialchars($data); return $data; }
    $name = test_input($_POST['name']);  $email = test_input($_POST['email']);  $phone = test_input($_POST['phone']);  $dob = $_POST['dob'];  $password = $_POST['pswd'];
    $confirm_password=$_POST['conf_pswd'];  $institute = test_input($_POST['institute']);  $campus = test_input($_POST['campus']);  $branch = test_input($_POST['branch']);
    $year = $_POST['year']; $rollno=$_POST['rollno'];  $city=test_input($_POST['city']);  $state=test_input($_POST['state']);  $country=test_input($_POST['country']);
    if (!preg_match("/^[a-zA-Z. ]*$/",$name)) { $nameerr="Invalid Name"; $flag=1; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $emailerr = "Invalid Email"; $flag=1; }
    if (!preg_match("/^[0-9 +]*$/",$phone)) { $phoneerr="Invalid Phone"; $flag=1; }
    if (!preg_match("/^[a-zA-Z-_() ]*$/",$campus)) { $campuserr="Invalid Campus/College Name"; $flag=1; }
    if (!preg_match("/^[a-zA-Z ]*$/",$branch)) { $brancherr="Invalid Branch Name"; $flag=1; }
    if (!preg_match("/^[a-zA-Z ]*$/",$city)) { $cityerr="Invalid City"; $flag=1; }
    if (!preg_match("/^[a-zA-Z ]*$/",$state)) { $stateerr="Invalid State"; $flag=1; }
    if (!preg_match("/^[a-zA-Z ]*$/",$country)) { $countryerr="Invalid Country"; $flag=1; }
    if (strcmp($password,$confirm_password)) { $passworderr="Passwords Did Not Match"; $flag=1; }

  if ($flag==0) {
      $conn = mysqli_connect($servername, $un, $pd, $dbname);
      if (!$conn) {
        echo "Connection Failed";
     }
     $check = "SELECT * FROM users WHERE email='".$email."'";
     $result = mysqli_query($conn,$check);
     if(mysqli_num_rows($result)==0){
      $query = "INSERT INTO users (sname,email,phone,college,campus,branch,syear,rollno,dob,city,state,country) VALUES ('".$name."','".$email."','".$phone."','".$institute."','".$campus."','".$branch."','".$year."','".$rollno."','".$dob."','".$city."','".$state."','".$country."')";
      $pwd = hash('sha512',$password);
      $query2= "INSERT INTO login (email,pswd) VALUES ('".$email."','".$pwd."')";
      if(mysqli_query($conn, $query)&&mysqli_query($conn,$query2)) {?> <script type="text/javascript">
        window.location.href = "reg_success.php";
      </script> <?php }
      else { ?> <script type="text/javascript">
        window.location.href = "reg_error.php";
      </script> <?php }}
      else {
        $emailerr = "Email Already Registered!"; $flag =1;
      }
      mysqli_close($conn);
  }}
   ?>
  <div class="w3-container w3-center">
    <h2>REGISTER</h2>
  </div>
  <div class="w3-quarter" style="color: #dd0000; font-weight: bold;">
    &nbsp;
  </div>
  <div class="w3-quarter">
    <div class="w3-container w3-left">
      <form class="w3-container" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="Name">Name</label>
        <input type="text" class="w3-input" name="name" value="<?php echo $name;?>" placeholder="Your Name" required> <span style="color: #dd0000"><?php echo $nameerr;?></span> <br>
        <label for="email">Email</label>
        <input type="email" class="w3-input" name="email" value="<?php echo $email;?>" placeholder="Your Email" required> <span style="color: #dd0000"><?php echo $emailerr;?></span> <br>
        <label for="password">Phone</label>
        <input type="tel" name="phone" class="w3-input" value="<?php echo $phone;?>" placeholder="Mobile Number" required> <span style="color: #dd0000"><?php echo $phoneerr;?></span> <br>
        <label for="dob">Date of Birth</label>
        <input type="date" name="dob" value="<?php echo $dob;?>" class="w3-input" required><br>
        <label for="password">Password</label>
        <input type="password" name="pswd" value="" class="w3-input" placeholder="********" required><br>
        <label for="conf_pass">Confirm Password</label>
        <input type="password" name="conf_pswd" class="w3-input" value="" placeholder="********" required> <span style="color: #dd0000"><?php echo $passworderr;?></span> <br>
        <label for="Name">College/University</label>
        <select class="w3-input" name="institute">
          <option value="SRMIST" <?php if($institute=="SRMIST") echo 'selected' ?>>SRM IST</option>
          <option value="NIT" <?php if($institute=="NIT") echo 'selected' ?>>NITs</option>
          <option value="IIT" <?php if($institute=="IIT") echo 'selected' ?>>IITs</option>
          <option value="IIIT" <?php if($institute=="IIIT") echo 'selected' ?>>IIITs</option>
          <option value="VIT" <?php if($institute=="VIT") echo 'selected' ?>>VIT</option>
          <option value="DU" <?php if($institute=="DU") echo 'selected' ?>>Delhi University</option>
          <option value="other" <?php if($institute=="other") echo 'selected' ?>>Others</option>
        </select><br>

    </div>
  </div>
  <div class="w3-quarter">
    <div class="w3-container w3-left">
        <label for="campus">Campus/College(in case Others)</label>
        <input type="text" class="w3-input" name="campus" value="<?php echo $campus;?>" placeholder="Campus of College/University" required> <span style="color: #dd0000"><?php echo $campuserr;?></span> <br>
        <label for="branch">Branch</label>
        <input type="text" name="branch" class="w3-input" value="<?php echo $branch;?>" placeholder="Your subject of study" required> <span style="color: #dd0000"><?php echo $brancherr;?></span> <br>
        <label for="year">Year</label>
        <select class="w3-input" name="year">
          <option value="1">I</option> <option value="2">II</option> <option value="3">III</option> <option value="4">IV</option>
        </select><br>
        <label for="rollno">College/University ID Number</label>
        <input type="text" name="rollno" value="<?php echo $rollno;?>" class="w3-input" placeholder="Student ID/Reg. No. of College" required><br>
        <label for="city">City</label>
        <input type="text" name="city" value="<?php echo $city;?>" class="w3-input" placeholder="City of your residence" required> <span style="color: #dd0000"><?php echo $cityerr;?></span> <br>
        <label for="state">State</label>
        <input type="text" name="state" value="<?php echo $state;?>" class="w3-input" placeholder="State of Residence" required><span style="color: #dd0000"><?php echo $stateerr;?></span><br>
        <label for="country">Country</label>
        <input type="text" name="country" value="<?php echo $country;?>" class="w3-input" required><span style="color: #dd0000"><?php echo $countryerr;?></span><br>
      <?php// } ?>

    </div>
  </div>
  <div class="w3-half">
    <div class="w3-container">
      <input type="submit" class="w3-button w3-black w3-left" name="submit" value="Register">&nbsp;&nbsp;&nbsp;
      <button type="button" class="w3-button w3-black" name="button" onclick="window.location.href='fgpwd.php'">Cancel</button>
    </div></form>
  </div>

<div class="w3-container w3-center"><br><br>
  By registering, you agree to the Terms & Conditions mentioned in <a href="rules.php" target="_blank">Rules</a> <br><br>
</div>

<!-- End page content -->
</div>


<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

</script>


</body>
</html>
